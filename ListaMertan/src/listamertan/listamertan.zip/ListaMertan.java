/*
 * Nev : Humayer Aliz 
 * datum: 2020.05.22.
 */

package listamertan;

public class ListaMertan {

    public static void main(String[] args) {
        System.out.print("Humayer Aliz 2020.05.24.\nListaMertan\n");        
         
    }  
}
