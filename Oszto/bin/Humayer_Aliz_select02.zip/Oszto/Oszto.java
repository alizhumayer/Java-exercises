
/*
* Nev : Humayer Aliz 
* datum: 2020.04.07.
*/

package Oszto;

public class Oszto {

   public static void main(String[] args) {
       System.out.print("Humayer Aliz 2020.04.07.\nOszto\n");        
        
   }  
}