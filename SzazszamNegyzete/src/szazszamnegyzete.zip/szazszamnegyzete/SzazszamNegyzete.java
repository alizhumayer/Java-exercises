/*
 * Nev : Humayer Aliz 
 * datum: 2020.04.24.
 */

package szazszamnegyzete;

public class SzazszamNegyzete {

    public static void main(String[] args) {
        System.out.print("Humayer Aliz 2020.04.24.\nOtvenszamNegyzete\n");        
         
    }  
}
