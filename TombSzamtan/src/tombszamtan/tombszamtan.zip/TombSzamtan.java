/*
 * Nev : Humayer Aliz 
 * datum: 2020.05.22.
 */

package tombszamtan;

public class TombSzamtan {

    public static void main(String[] args) {
        System.out.print("Humayer Aliz 2020.05.22.\nTombSzamtan\n");        
         
    }  
}
